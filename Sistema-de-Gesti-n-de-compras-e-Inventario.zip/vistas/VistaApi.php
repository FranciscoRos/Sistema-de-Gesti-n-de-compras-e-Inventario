<?php

abstract class VistaApi
{
    public $estado;

    public abstract function imprimir($cuerpo);
}
